
package com.futboldemo.mslegacyrouting.model;

public class PayloadItem {

	@Override
	public String toString() {
		return "PayloadItem{" +
				"}";
	}
}